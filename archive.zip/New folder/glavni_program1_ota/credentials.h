#pragma once
const char* mySSID = "net4gear";
const char* myPASSWORD = "dnevnasoba";