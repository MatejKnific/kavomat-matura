#define USERNAME "matejknific"
#define DEVICE_ID "kavomat"
#define DEVICE_CREDENTIAL "4U#&Tn?8!&OSaSlJ"

#define SSID "net4gear"
#define SSID_PASSWORD "dnevnasoba"