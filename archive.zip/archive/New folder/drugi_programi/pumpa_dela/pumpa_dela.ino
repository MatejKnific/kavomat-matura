/*
 * 
 * 
 * 
 */
unsigned long previousMillis = 0;
unsigned long currentMillis;
const long interval = 8; //10 max, in najmanjsa hitrost
int pumpa = 26;//26
int a=0;
bool state = true;

void IRAM_ATTR i() {
  //Serial.println("1");//prevelik ukaz za v interrupt
  currentMillis = millis();
  //digitalWrite(pumpa, 0);
  a++;
  if (a >= 4){
    digitalWrite(pumpa, 0);
    state = false;
    }
  if (a >= 6){
    a=0; 
    state = true; 
    }
  }
  
void setup() {
  // put your setup code here, to run once:
  Serial.begin(115200);
  pinMode(17, INPUT);
  pinMode(pumpa, OUTPUT);
  attachInterrupt(17, i, RISING);
}

void loop() {
  previousMillis = millis();
  // put your main code here, to run repeatedly:
  if (previousMillis - currentMillis >= interval){  //if (cas od int >= interval)
    if (state){
      digitalWrite(pumpa, 1);//pumpa on
  }}
  delayMicroseconds(5);
}
