/*
*
*
*
*
*/

const int LEDPin = 26;  /* GPIO16 */

int dutyCycle;
/* Setting PWM Properties */
const int PWMFreq = 200; /* 500 Hz */
const int PWMChannel = 0;
const int PWMResolution = 8;/*0-255*/
const int MAX_DUTY_CYCLE = (int)(pow(2, PWMResolution) - 1);




void setup() {
  // put your setup code here, to run once:

  //pinMode(26, OUTPUT);
  Serial.begin(115200);
  pinMode(17, INPUT);
  ledcSetup(PWMChannel, PWMFreq, PWMResolution);
  /* Attach the LED PWM Channel to the GPIO Pin */
  ledcAttachPin(LEDPin, PWMChannel);
  attachInterrupt(17, i, RISING);

}

void loop() {
  Serial.println(digitalRead(17));
  Serial.println("v lupu");
}


void i() {
  dutyCycle = 50;//127
  ledcWrite(PWMChannel, dutyCycle);
}
