hw_timer_t * timer;
// Set the digital output pin connected to the triac's gate
const int triacPin = 26;

// Set the digital input pin connected to the zero-cross detection module's OUT pin
const int zcPin = 17;

// Define the PWM frequency in Hz (i.e., the number of cycles per second)
const int pwmFrequency = 50;

// Define the duty cycle as a percentage (0-100)
const int dutyCycle = 5;

// Define the PWM period in microseconds (1 / pwmFrequency * 1000000)
const int pwmPeriod = 20000;

// Define the PWM on time in microseconds (pwmPeriod * dutyCycle / 100)
const int pwmOnTime = 10000;

// Define the interrupt handler function
void IRAM_ATTR pwmInterruptHandler() {
  // Set the triacPin to HIGH
  digitalWrite(triacPin, HIGH);

  // Set the timer interrupt to trigger again after the PWM on time has elapsed
  timerWrite(0, pwmOnTime * 1000);
}

void setup() {
  // Set the triacPin as an output
  pinMode(triacPin, OUTPUT);

  // Set the zcPin as an input and enable interrupts
  pinMode(zcPin, INPUT);
attachInterrupt(digitalPinToInterrupt(zcPin), pwmInterruptHandler, RISING); //Falling

  // Configure the timer interrupt with the specified period
  timer = timerBegin(0, 80, true);
  timerAttachInterrupt(timer, &pwmInterruptHandler, true);
  timerAlarmWrite(timer, pwmPeriod * 1000, true);
  timerAlarmEnable(timer);
}

void loop() {
  // The rest of your code goes here...
}
