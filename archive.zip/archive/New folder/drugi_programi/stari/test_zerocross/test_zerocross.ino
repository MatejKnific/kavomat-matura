/*
 *
 * 
 * 
 * 
 * 
 * 
 */


 
void setup() {
  // put your setup code here, to run once:
  
pinMode(26, OUTPUT);
Serial.begin(115200);
pinMode(17, INPUT);
attachInterrupt(17, drekecPekec, RISING);

}

void loop(){
  Serial.println(digitalRead(17));
  }


  void drekecPekec(){
  delayMicroseconds(5000);
  digitalWrite(26, HIGH);
  delayMicroseconds(100);
  digitalWrite(26, LOW);
}
