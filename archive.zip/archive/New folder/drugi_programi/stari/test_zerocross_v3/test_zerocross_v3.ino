unsigned long previousMillis = 0;
unsigned long currentMillis;
const long interval = 10; 

void setup() {
  // put your setup code here, to run once:
  Serial.begin(115200);
  pinMode(17, INPUT);
  pinMode(26, OUTPUT);
  attachInterrupt(17, i, RISING);
}

void loop() {
  
  // put your main code here, to run repeatedly:
  currentMillis = millis();
  //Serial.println(digitalRead(17));
  //Serial.println("v lupu");
}
void i() {
  Serial.println("1");
  digitalWrite(26, 1);
  if (currentMillis - previousMillis >= interval){
    previousMillis = currentMillis;
    digitalWrite(26, 0);
    Serial.println("0");
  }
  }
