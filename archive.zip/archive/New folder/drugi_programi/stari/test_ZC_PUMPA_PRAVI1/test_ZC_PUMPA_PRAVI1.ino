/*
 * 
 * 
 * 
 */
const int triacPin = 26;
const int zcPin = 17;
const int duty = 2;

void iszero(){
  digitalWrite(triacPin, LOW);
  delay(2);//10 max = 0%
  digitalWrite(triacPin, HIGH);
  delay(4);
  digitalWrite(triacPin, LOW);
  
  }

void setup() {
    // Set the triacPin as an output
  pinMode(triacPin, OUTPUT);

  // Set the zcPin as an input and enable interrupts
  pinMode(zcPin, INPUT);
  
  attachInterrupt(digitalPinToInterrupt(zcPin), iszero, RISING); //rising
}




void loop() {
  // The rest of mine code goes here...

}
