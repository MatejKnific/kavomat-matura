/*
 * 
 * 
 * 
 */
unsigned long previousMillis = 0;
unsigned long currentMillis;
const long interval = 5; //10 max 
int pumpa = 25;//26 pumpa / 25 grelec
bool state = false;

void IRAM_ATTR i() {
  //Serial.println("1");//prevelik ukaz za v interrupt
  currentMillis = millis();
  //digitalWrite(pumpa, 0);
  state = true;
  }
  
void setup() {
  // put your setup code here, to run once:
  Serial.begin(115200);
  pinMode(17, INPUT);
  pinMode(pumpa, OUTPUT);
  attachInterrupt(17, i, RISING);
}

void loop() {
  previousMillis = millis();
  // put your main code here, to run repeatedly:
  if (previousMillis - currentMillis >= interval){//if (cas od int - cas)
    
    if (state){
      digitalWrite(pumpa, 1);//pumpa on
      delayMicroseconds(100);//(puls T=100us)
      digitalWrite(pumpa, 0);//pumpa off
      state = false;
  //Serial.println("0");
  //Serial.println(digitalRead(17));
  //Serial.println("v lupu");
 }}
  delayMicroseconds(5);
}
