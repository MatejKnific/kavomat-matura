/*
 * 
 * 
 * 
 */
unsigned long previousMillis = 0;
unsigned long currentMillis;
const long interval = 5; //10 max 
int pumpa = 26;//26

void IRAM_ATTR i() {
  //Serial.println("1");//prevelik ukaz za v interrupt
  currentMillis = millis();
  digitalWrite(pumpa, 0);
  }
  
void setup() {
  // put your setup code here, to run once:
  Serial.begin(115200);
  pinMode(17, INPUT);
  pinMode(pumpa, OUTPUT);
  attachInterrupt(17, i, RISING);
}

void loop() {
  previousMillis = millis();
  // put your main code here, to run repeatedly:
  if (previousMillis - currentMillis >= interval){  //if (cas od int - cas)
    
    digitalWrite(pumpa, 1);//pumpa on
  //Serial.println("0");
  //Serial.println(digitalRead(17));
  //Serial.println("v lupu");
  }
  delayMicroseconds(5);
}
