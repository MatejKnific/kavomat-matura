/* koncna verzija z long short press gumbom, timerjem, grelecem, crpalko in termistorjem

ideje za v3: pokrov, nivo vode rled.Proti parna zaščita, bluetooth možnost nastavitve velikosti kozarca na ml ter t na c

--proti para if t2 < 97 then grelec off delay 1s grelec on
*/


#include <DS3231.h> //Include the clock library
int ledm = 10;// led modra
int ledz = 11;//led zelena
int ledr = 12;//led rdeča

int setHour = 5; // Set hours of timer 
int setMin = 10; // Set minute of timer

int c = 0;
int a=0;
int b=0;
int sensorValue = 0;
int sensorValue2 = 0;
int ong=9;//on gumb, pritisk je dela kavo, dolg pritisk je on off timer 

float t3 = 0;
float t2 = 0;
float voltage = 0;
float voltage2 = 0;
float k = 0.035;//20-90 c
float k1 =0.022 ;//10-20 c
float k2 =0.026 ;//20-30 c
float k3 =0.039 ;//30-40 c
float k4 =0.036 ;//40-50 c
float k5 =0.038 ;//50-60 c
float k6 =0.044 ;//60-70 c
float k7 =0.034 ;//70-80 c
float k8 =0.028 ;//80-90 c
float n1 =0.47 ;//10-20 c
float n2 =0.39 ;//20-30 c
//float n3 =0 ;//30-40 c
float n4 =0.12 ;//40-50 c
float n5 =0.02 ;//50-60 c
float n6 =0.34 ;//60-70 c
float n7 =0.36 ;//70-80 c
float n8 =0.84 ;//80-90 c

DS3231  rtc(SDA, SCL);
Time t;

long buttonTimer = 0;
long longPressTime = 5000;

boolean buttonActive = false;
boolean longPressActive = false;

void setup() {
  // put your setup code here, to run once:
  Serial.begin(9600);
  Serial.print("ready");
  pinMode(ong, INPUT);
  pinMode(3, OUTPUT);//crpalka
  pinMode(ledm, OUTPUT);
  pinMode(ledz, OUTPUT);
  pinMode(ledr, OUTPUT);
  pinMode(4, OUTPUT);//Grelec
  pinMode(13, OUTPUT);//built in led
  pinMode(A7, INPUT);//termistor1
  pinMode(A6, INPUT);//termistor2
  digitalWrite(3, LOW);
  digitalWrite(13, LOW);
  digitalWrite(4, LOW);
  rtc.begin();
}
void dela(){
   digitalWrite(4, HIGH);
 
  while (b < 425){   //delujoce 30 z delay 1000/500
    if (b < 425){
      digitalWrite(ledm, HIGH);
      digitalWrite(3, HIGH);
      digitalWrite(13, HIGH);
      // digitalWrite(4, HIGH);
      delay(50);//delujoce 1000-1/500-0
      digitalWrite(3, LOW);
      digitalWrite(13, LOW);
      digitalWrite(ledm, LOW);
      //digitalWrite(4, LOW);
    
      delay(100);}
    b++;
    Serial.println(b);
   
      
    if (b <= 400 && b>70){
      digitalWrite(4, HIGH);
      delay(50);
      digitalWrite(4, LOW);
      Serial.println("ne dela grelc");
     // delay(10);
     if (t2>94){
  digitalWrite(12,HIGH);}
  else{digitalWrite(12,LOW);}
  }
  
  }
   b=0; 
  Serial.print("konec dela");
}  //konec void dela

void loop() {
  t = rtc.getTime(); // Make a time class called 't'
// Send Day-of-Week
  //Serial.print(rtc.getDOWStr());
 // Serial.print(" ");
  
  // Send date
//  Serial.print(rtc.getDateStr());
 // Serial.print(" -- ");

  // Send time
//Serial.println(rtc.getTimeStr());
  if (c == 1){
    digitalWrite(ledz, HIGH); 
    Serial.println("timer on" );
      if (t.hour == setHour && t.min == setMin) // Check if it's time to wake up!
    {
        Serial.println("bip bip");
        dela();
    
  }}
  else{digitalWrite(ledz,LOW);
    }
  if (c >= 2){
    c=0;
    Serial.print("timer off");}

  
  if (digitalRead(ong) == HIGH) {

    if (buttonActive == false) {

      buttonActive = true;
      buttonTimer = millis();

    }

    if ((millis() - buttonTimer > longPressTime) && (longPressActive == false)) {
      longPressActive = true;
      Serial.println("long press");
      c++;
  
      
       }

  } else {

    if (buttonActive == true) {

      if (longPressActive == true) {

        longPressActive = false;

      } else {

       //short press
        dela();
        Serial.println("short press");
        delay(10);

      }

      buttonActive = false;

    }

  }
  
  
/*int on = digitalRead(ong);//on/on gumb
 if (on == HIGH){   
    dela();}*/
    
  sensorValue = analogRead(A7);  
  sensorValue2 = analogRead(A6);
  voltage = sensorValue * (5.0 / 1023.0);
  voltage2 = sensorValue2 * (5.0 / 1023.0);
//  Serial.println(voltage);

//----------------1  

 // if ( (val == val2) && (val != buttonstate)  ) {

  if ((voltage > 0)&&( voltage <=0.91)){
    t3 = (voltage - n1) / k1;
 }
  if ((voltage2 > 0)&&( voltage2 <=0.91)){
    t2 = (voltage2 - n1) / k1;
 }
 
//_----------------------2
  if ((voltage > 0.91)&&( voltage <=1.17)){
    t3 = (voltage - n2) / k2;
 }
  if ((voltage2 > 0.91)&&( voltage2 <=1.17)){
    t2 = (voltage2 - n2) / k2;
 }
//-------------------------3
  if ((voltage > 1.17)&&( voltage <=1.56)){
  
    t3 = voltage / k3;
 }
 if ((voltage2 > 1.17)&&( voltage2 <=1.56)){
  
    t2 = voltage2 / k3;
 }
//-----------------------4
  if ((voltage > 1.56)&&( voltage <=1.92)){
    t3 = (voltage - n4) / k4;
 }
  if ((voltage2 > 1.56)&&( voltage2 <=1.92)){
    t2 = (voltage2 - n4) / k4;
 }
//---------------------5
  if ((voltage > 1.92)&&( voltage <=2.3)){
    t3 = (voltage - n5) / k5;
 }
  if ((voltage2 > 1.92)&&( voltage2 <=2.3)){
    t2 = (voltage2 - n5) / k5;
 }
//----------------------6
  if ((voltage > 2.3)&&( voltage <=2.74)){
    t3 = (voltage + n6) / k6;
 }
  if ((voltage2 > 2.3)&&( voltage2 <=2.74)){
    t2 = (voltage2 + n6) / k6;
 }
//----------------------7
  if ((voltage > 2.74)&&( voltage <=3.08)){
    t3 = (voltage - n7) / k7;
 }
  if ((voltage2 > 2.74)&&( voltage2 <=3.08)){
    t2 = (voltage2 - n7) / k7;
 }
//----------------------8
  if (voltage > 3.08){
    t3 = (voltage - n8) / k8;
 }
  if (voltage2 > 3.08){
    t2 = (voltage2 - n8) / k8;
 }
 /*Serial.print("t1=");
 Serial.println(t3);
 Serial.print("t2=");
 Serial.println(t2);*/

if (t2>94){
  digitalWrite(12,HIGH);}
  else{digitalWrite(12,LOW);}
}
