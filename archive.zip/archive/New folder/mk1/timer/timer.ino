
#include <DS3231.h> //Include the clock library

int setHour = 10; // Set hours to wake
int setMin = 30; // Set minute to wake

int buttonState = 0;

DS3231  rtc(SDA, SCL);
Time t;
void start();
 
void setup()
{
  pinMode(2, OUTPUT);//mikro stikalo
  pinMode(3, OUTPUT);//gumb
  pinMode(4, INPUT);// on/off stikalo
  pinMode(5, OUTPUT);// Vcc
  pinMode(6, OUTPUT);// Vcc
  pinMode(7, OUTPUT);// gumb 2 vzporedno tokovno drugace potreben samo en output
  Serial.begin(9600); // Match to serial monitor
  rtc.begin();
}

void loop()
{
  buttonState = digitalRead(4);
  digitalWrite(5, HIGH);
  digitalWrite(6, HIGH);
  t = rtc.getTime(); // Make a time class called 't'
  
  // Send Day-of-Week
  Serial.print(rtc.getDOWStr());
  Serial.print(" ");
  
  // Send date
  Serial.print(rtc.getDateStr());
  Serial.print(" -- ");

  // Send time
  Serial.println(rtc.getTimeStr());
  if (buttonState == HIGH){
    Serial.println("timer on" );
    if (t.hour == setHour && t.min == setMin) // Check if it's time to wake up!
    {
    Serial.println("bip bip");
    start();
    
  }}
  
  // Wait one second before repeating
  delay (1000);
}

void start()
{
Serial.println("delam kavo");
digitalWrite(2,HIGH);
delay(500);
digitalWrite(2, LOW);
delay(4000);
digitalWrite(3, HIGH);
digitalWrite(7, HIGH);
delay(1000);
digitalWrite(3, LOW);
digitalWrite(7, LOW);
delay(60000);


}
