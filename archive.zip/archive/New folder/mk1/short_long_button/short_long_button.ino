
int button = 9;


long buttonTimer = 0;
long longPressTime = 5000;

boolean buttonActive = false;
boolean longPressActive = false;

void setup() {

  pinMode(button, INPUT);
  Serial.begin(9600);

}

void loop() {

  if (digitalRead(button) == HIGH) {

    if (buttonActive == false) {

      buttonActive = true;
      buttonTimer = millis();

    }

    if ((millis() - buttonTimer > longPressTime) && (longPressActive == false)) {

      longPressActive = true;
      Serial.println("long press");
       }

  } else {

    if (buttonActive == true) {

      if (longPressActive == true) {

        longPressActive = false;

      } else {

       
        Serial.println("short press");
        delay(10);

      }

      buttonActive = false;

    }

  }

}
