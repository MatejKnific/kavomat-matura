void setup() {
  // put your setup code here, to run once:
pinMode(3,OUTPUT);
pinMode(13,OUTPUT);//built in led
digitalWrite(3,LOW);
digitalWrite(13,LOW);
}

void loop() {
  // put your main code here, to run repeatedly:
digitalWrite(3,LOW);
digitalWrite(13,LOW);
delay(10000);
digitalWrite(3,HIGH);
digitalWrite(13,HIGH);
delay(2000);
}
