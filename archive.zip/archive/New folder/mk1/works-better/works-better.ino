/* koncna verzija ; works better

  ideje za v3: pokrov, nivo vode rled. bluetooth možnost nastavitve velikosti kozarca na ml ter t na c

*/


#include <DS3231.h> //Include the clock library
int ledm = 10;// led modra
int ledz = 11;//led zelena
int ledr = 12;//led rdeča

int setHour = 5; // Set hours of timer
int setMin = 10; // Set minute of timer

int c = 0;
int a = 0;
int b = 0;
int sensorValue = 0;
int sensorValue2 = 0;
int ong = 9; //on gumb, pritisk je dela kavo, dolg pritisk je on off timer

float temp = 0;
bool zacetek = true;
bool konec = false;
int wtemp = 80;

float t3 = 0;
float t2 = 0;
float voltage = 0;
float voltage2 = 0;
float k = 0.035;//20-90 c
float k1 = 0.022 ; //10-20 c
float k2 = 0.026 ; //20-30 c
float k3 = 0.039 ; //30-40 c
float k4 = 0.036 ; //40-50 c
float k5 = 0.038 ; //50-60 c
float k6 = 0.044 ; //60-70 c
float k7 = 0.034 ; //70-80 c
float k8 = 0.028 ; //80-90 c
float n1 = 0.47 ; //10-20 c
float n2 = 0.39 ; //20-30 c
//float n3 =0 ;//30-40 c
float n4 = 0.12 ; //40-50 c
float n5 = 0.02 ; //50-60 c
float n6 = 0.34 ; //60-70 c
float n7 = 0.36 ; //70-80 c
float n8 = 0.84 ; //80-90 c

DS3231  rtc(SDA, SCL);
Time t;

long buttonTimer = 0;
long longPressTime = 5000;

boolean buttonActive = false;
boolean longPressActive = false;

void setup() {
  // put your setup code here, to run once:
  Serial.begin(9600);
  Serial.print("ready");
  pinMode(ong, INPUT);
  pinMode(3, OUTPUT);//crpalka
  pinMode(ledm, OUTPUT);
  pinMode(ledz, OUTPUT);
  pinMode(ledr, OUTPUT);
  pinMode(4, OUTPUT);//Grelec
  pinMode(13, OUTPUT);//built in led
  pinMode(A7, INPUT);//termistor1
  pinMode(A6, INPUT);//termistor2
  digitalWrite(3, LOW);
  digitalWrite(13, LOW);
  digitalWrite(4, LOW);
  rtc.begin();
}
void(* resetFunc) (void) = 0; //declare reset function @ address 0

void worksBetter(){

  Serial.print("Inside worksBetter");
  analogWrite(3, 1); // pwm nastima crpalko na čisto počasi %

  digitalWrite(ledm, HIGH);

 
 int startTime = millis();
 while(millis() - startTime < 55000) { //cajt za nardit kavo
    Serial.print("Inside worksBetter while");
    Serial.print("Pretekli cas: ");
    int time = millis() - startTime;
    Serial.print(time);
    // get temp
    getTemp(); 
    
    if (t2 <= wtemp-10) {
      // palimo grelec
      digitalWrite(4, HIGH);
      Serial.print("Inside worksBetter temp je pod 70 -> uzigam");
    }
    else if (t2 >= wtemp) {
      // ugasnemo grelec
      digitalWrite(4, LOW);
      Serial.print("Inside worksBetter temp je nad 80 -> ugasam");
    }
    
 }
 

 digitalWrite(4, LOW); // ugasnemo grelec

 delay(5000); // za shladit grelec
 digitalWrite(ledm, LOW); //ugasnemo ledico
 analogWrite(3, 0); // ugasnemo crpalko
 Serial.print("End of worksBetter");
 Serial.print("reseting");
 delay(500);
 resetFunc();  //call reset
 
 
}


void loop() {

  t = rtc.getTime(); // Make a time class called 't'
  getTemp();
  
  // c=1 je timer upaljen
  if (c == 1) {
    digitalWrite(ledz, HIGH);
    Serial.println("timer on" );

    // Check if it's time to wake up!
    if (t.hour == setHour && t.min == setMin) {
      Serial.println("bip bip");
      worksBetter();
    }
  }
  // c=2 ugasni timer
  else if (c >= 2) {
    c = 0;
    Serial.print("timer off");
    digitalWrite(ledz, LOW);
  }

  // gumb pressed
  if (digitalRead(ong) == HIGH) {

    // start timer for long or short press of the button
    if (buttonActive == false) {

      buttonActive = true;
      buttonTimer = millis();
    }

    // handling long press of the button -> turn on/off timer
    if ((millis() - buttonTimer > longPressTime) && (longPressActive == false)) {
      longPressActive = true;
      Serial.println("long press");

      if (c == 0) {
        c = 1; // active
      }
      else if (c == 1) { 
        c = 2; // shut sensor down
      }

    }
  }
  else { // button not pressed

    if (buttonActive == true) {

      if (longPressActive == true) {

        longPressActive = false;
      }
      else {
        //short press -> make coffe
        worksBetter();
        Serial.println("short press");
        delay(10);

      }
      buttonActive = false;
    }
  }
}


void getTemp() {

  sensorValue = analogRead(A7);
  // gledamo tega
  sensorValue2 = analogRead(A6);
  voltage = sensorValue * (5.0 / 1023.0);
  voltage2 = sensorValue2 * (5.0 / 1023.0);

  if ((voltage > 0) && ( voltage <= 0.91)) {
    t3 = (voltage - n1) / k1;
  }
  if ((voltage2 > 0) && ( voltage2 <= 0.91)) {
    t2 = (voltage2 - n1) / k1;
  }

  //_----------------------2
  if ((voltage > 0.91) && ( voltage <= 1.17)) {
    t3 = (voltage - n2) / k2;
  }
  if ((voltage2 > 0.91) && ( voltage2 <= 1.17)) {
    t2 = (voltage2 - n2) / k2;
  }
  //-------------------------3
  if ((voltage > 1.17) && ( voltage <= 1.56)) {

    t3 = voltage / k3;
  }
  if ((voltage2 > 1.17) && ( voltage2 <= 1.56)) {

    t2 = voltage2 / k3;
  }
  //-----------------------4
  if ((voltage > 1.56) && ( voltage <= 1.92)) {
    t3 = (voltage - n4) / k4;
  }
  if ((voltage2 > 1.56) && ( voltage2 <= 1.92)) {
    t2 = (voltage2 - n4) / k4;
  }
  //---------------------5
  if ((voltage > 1.92) && ( voltage <= 2.3)) {
    t3 = (voltage - n5) / k5;
  }
  if ((voltage2 > 1.92) && ( voltage2 <= 2.3)) {
    t2 = (voltage2 - n5) / k5;
  }
  //----------------------6
  if ((voltage > 2.3) && ( voltage <= 2.74)) {
    t3 = (voltage + n6) / k6;
  }
  if ((voltage2 > 2.3) && ( voltage2 <= 2.74)) {
    t2 = (voltage2 + n6) / k6;
  }
  //----------------------7
  if ((voltage > 2.74) && ( voltage <= 3.08)) {
    t3 = (voltage - n7) / k7;
  }
  if ((voltage2 > 2.74) && ( voltage2 <= 3.08)) {
    t2 = (voltage2 - n7) / k7;
  }
  //----------------------8
  if (voltage > 3.08) {
    t3 = (voltage - n8) / k8;
  }
  if (voltage2 > 3.08) {
    t2 = (voltage2 - n8) / k8;
  }
  Serial.print("t3=");
  Serial.println(t3);
  Serial.print("t2=");
  Serial.println(t2);

}
