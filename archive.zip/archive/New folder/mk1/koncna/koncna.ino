int a=0;
int b=0;
int sensorValue = 0;
int sensorValue2 = 0;
int ong=9;//on gumb, pritisk je dela kavo
float t = 0;
float t2 = 0;
float voltage = 0;
float voltage2 = 0;

float k = 0.035;//20-90 c
float k1 =0.022 ;//10-20 c
float k2 =0.026 ;//20-30 c
float k3 =0.039 ;//30-40 c
float k4 =0.036 ;//40-50 c
float k5 =0.038 ;//50-60 c
float k6 =0.044 ;//60-70 c
float k7 =0.034 ;//70-80 c
float k8 =0.028 ;//80-90 c

float n1 =0.47 ;//10-20 c
float n2 =0.39 ;//20-30 c
//float n3 =0 ;//30-40 c
float n4 =0.12 ;//40-50 c
float n5 =0.02 ;//50-60 c
float n6 =0.34 ;//60-70 c
float n7 =0.36 ;//70-80 c
float n8 =0.84 ;//80-90 c


void setup() {
  // put your setup code here, to run once:
  Serial.begin(9600);
  pinMode(ong, INPUT);
  pinMode(3, OUTPUT);//crpalka
  pinMode(4, OUTPUT);//Grelec
  pinMode(13, OUTPUT);//built in led
  pinMode(A7, INPUT);//termistor1
  pinMode(A6, INPUT);//termistor2
  digitalWrite(3, LOW);
  digitalWrite(13, LOW);
  digitalWrite(4, LOW);
  delay(5000);
}
void dela(){
    digitalWrite(4, HIGH);
 
  while (b < 450){   //delujoce 30 z delay 1000/500
  
    digitalWrite(3, HIGH);
    digitalWrite(13, HIGH);
    delay(50);//delujoce 1000-1/500-0
    digitalWrite(3, LOW);
    digitalWrite(13, LOW);
    delay(65);
    b++;
    Serial.println(b);
    if (b >= 400){
      digitalWrite(4, LOW);
      Serial.println("ne dela grelc");
  }
  
  }
   b=0; 
  Serial.print("konec dela");
}  //konec void dela

void loop() {

  // put your main code here, to run repeatedly:
  int on = digitalRead(ong);//on/on gumb
 if (on == HIGH){   
    dela();}
  sensorValue = analogRead(A7);  
  sensorValue2 = analogRead(A6);
  voltage = sensorValue * (5.0 / 1023.0);
  voltage2 = sensorValue2 * (5.0 / 1023.0);
//  Serial.println(voltage);

//----------------1  

 // if ( (val == val2) && (val != buttonstate)  ) {

  if ((voltage > 0)&&( voltage <=0.91)){
    t = (voltage - n1) / k1;
 }
  if ((voltage2 > 0)&&( voltage2 <=0.91)){
    t2 = (voltage2 - n1) / k1;
 }
 
//_----------------------2
  if ((voltage > 0.91)&&( voltage <=1.17)){
    t = (voltage - n2) / k2;
 }
  if ((voltage2 > 0.91)&&( voltage2 <=1.17)){
    t2 = (voltage2 - n2) / k2;
 }
//-------------------------3
  if ((voltage > 1.17)&&( voltage <=1.56)){
  
    t = voltage / k3;
 }
 if ((voltage2 > 1.17)&&( voltage2 <=1.56)){
  
    t2 = voltage2 / k3;
 }
//-----------------------4
  if ((voltage > 1.56)&&( voltage <=1.92)){
    t = (voltage - n4) / k4;
 }
  if ((voltage2 > 1.56)&&( voltage2 <=1.92)){
    t2 = (voltage2 - n4) / k4;
 }
//---------------------5
  if ((voltage > 1.92)&&( voltage <=2.3)){
    t = (voltage - n5) / k5;
 }
  if ((voltage2 > 1.92)&&( voltage2 <=2.3)){
    t2 = (voltage2 - n5) / k5;
 }
//----------------------6
  if ((voltage > 2.3)&&( voltage <=2.74)){
    t = (voltage + n6) / k6;
 }
  if ((voltage2 > 2.3)&&( voltage2 <=2.74)){
    t2 = (voltage2 + n6) / k6;
 }
//----------------------7
  if ((voltage > 2.74)&&( voltage <=3.08)){
    t = (voltage - n7) / k7;
 }
  if ((voltage2 > 2.74)&&( voltage2 <=3.08)){
    t2 = (voltage2 - n7) / k7;
 }
//----------------------8
  if (voltage > 3.08){
    t = (voltage - n8) / k8;
 }
  if (voltage2 > 3.08){
    t2 = (voltage2 - n8) / k8;
 }
 /*Serial.print("t1=");
 Serial.println(t);
 Serial.print("t2=");
 Serial.println(t2);
*/
}
