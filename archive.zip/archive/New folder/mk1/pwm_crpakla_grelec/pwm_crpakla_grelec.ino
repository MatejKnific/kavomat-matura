int b=0;


void setup() {
  // put your setup code here, to run once:
  Serial.begin(9600);
pinMode(3,OUTPUT);//crpalka
pinMode(4, OUTPUT);//Grelec
pinMode(13,OUTPUT);//built in led
digitalWrite(3,LOW);
digitalWrite(13,LOW);
digitalWrite(4,LOW);
delay(5000);
}

void loop() {
  // put your main code here, to run repeatedly:
digitalWrite(4,HIGH);
if (b >= 400){
  digitalWrite(4,LOW);
  Serial.print("ne dela grelc");
  }
if (b < 400){   //delujoce 30 z delay 1000/500
digitalWrite(3,HIGH);
digitalWrite(13,HIGH);
delay(50);//delujoce 1000-1/500-0
digitalWrite(3,LOW);
digitalWrite(13,LOW);
delay(65);
b++;
Serial.print(b);

}

}
