char junk;
String inputString="";
String vValue = "";
String tValue = "";
int vInt;
int tInt;
char color[24];
String cur_col;

void setup() {
  // put your setup code here, to run once:
 Serial.begin(9600); 
}

void loop() {
  // put your main code here, to run repeatedly:
 if ( Serial.available() > 0 ){
  vValue="";
  vInt=0;
  tValue="";
  tInt=0;
  cur_col = ""; 



  for ( int i = 0; i < 24; i++ ) { 
  color[i] = {};
  delay(10);
  } for ( int i = 0; i < 12; i++ )
  { color[i] = Serial.read();
  Serial.print( color[i] );
  delay(50);
  } for ( int i = 0; i < 12; i++ )
  { if ( color[i] == 'V' )
  { cur_col = "V"; } if ( color[i] == 'T' ) 
  { cur_col = "T"; } if ( color[i] == 'V' ) 
  
  { vValue += String(color[i]); delay(10); }
  if ( cur_col == "T" ) 
  { tValue += String(color[i]); delay(10); }
  
  } } vValue.replace( "V", "" ); 
 // RED 
 vInt = vValue.toInt();
 tValue.replace( "T", "" ); 
 // GREEN
 tInt = tValue.toInt();
 Serial.println("t");
 Serial.println(tInt);
 Serial.println("v");
 Serial.println(vInt);
 delay(500);
 
  
  
  
  }
