// NTC B3950 Thermistor
// the formula for temp in kelvin is
//                 1
// T = ----------------------------
//     1/To + (1/beta) * ln(Rt/Ro)
//
// https://en.wikipedia.org/wiki/Thermistor

// ESP32 ADC non-liear issue
// https://www.esp32.com/viewtopic.php?t=1045
// https://github.com/espressif/esp-idf/issues/164
// https://docs.espressif.com/projects/esp-idf/en/latest/api-reference/peripherals/adc.html#adc-calibration

bool esp32 = true;       // change to false when using Arduino

int ThermistorPin;
double adcMax, Vs;

double R1 = 10000.0;   // voltage divider resistor value
double Beta = 3871.22;  // Beta value
double To = 298.15;    // Temperature in Kelvin for 25 degree Celsius
double Ro = 8000;   // Resistance of Thermistor at 25 degree Celsius

// The ESP32 lookup table varies from device to device, use the program from 
// https://github.com/e-tinkers/esp32-adc-calibrate
// to generate lookup table for your own ESP32



void setup() {
  Serial.begin(115200);
  if (esp32) {
    ThermistorPin = 35;
    adcMax = 4095.0; // ADC resolution 12-bit (0-4095)
    Vs = 3.3;        // supply voltage
  }
  else {
    ThermistorPin = A0;
    adcMax = 1023.0; // ADC resolution 10-bit (0-1023)
    Vs = 5.0;          // supply voltage
  }
}

void loop() {
  double Vout, Rt = 0;
  double T, Tc, Tf = 0;

  double adc = 0;
  if (esp32) {
    adc = analogRead(ThermistorPin);
    
  }
  else {
    adc = analogRead(ThermistorPin);
  }
  Vout = adc * Vs/adcMax;
  Rt = R1 * Vout / (Vs - Vout);

 // T = 1/(1/To + log(Rt/Ro)/Beta);  
 T = 1/(1/To - log(Rt/Ro)/Beta); // Temperature in Kelvin
  Tc = T - 273.15;                   // Celsius

  //if (Tc > 0) 
  Serial.println(Tc);

  delay(2000);
}
