

void setup() {
  pinMode(27, INPUT_PULLUP);
  pinMode(3,1);
  Serial.begin(112500);
}

void loop() {
  if(digitalRead(27) == 0) {
    delay(200);
    digitalWrite(3,1);
    Serial.println("pritisnjeno");
    }
  else{ 
    digitalWrite(3,0);
    }
   
  }
