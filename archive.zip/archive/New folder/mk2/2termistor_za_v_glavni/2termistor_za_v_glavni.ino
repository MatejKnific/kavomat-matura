/*
*         2 - termistorja (tmax, tmin) za v glavni program kavomata
*
*/

int ThermistorPin, ThermistorPin2;
double adcMax, Vs;

double R1 = 10000.0;   // voltage divider resistor value
double Beta = 3871.22;  // Beta value
double To = 298.15;    // Temperature in Kelvin for 25 degree Celsius
double Ro = 8000;   // Resistance of Thermistor at 25 degree Celsius





void setup() {
  Serial.begin(115200);
  
  ThermistorPin = 34;
  ThermistorPin2 = 35;
  adcMax = 4095.0; // ADC resolution 12-bit (0-4095)
  Vs = 3.3;        // supply voltage

}

void loop() {
  double Vout, Rt, Vout2, Rt2 = 0;
  double T, Tc, Tf, T2, Tc2, Tf2 = 0;

  double adc, adc2 = 0;
  
 
  adc = analogRead(ThermistorPin);
  adc2 = analogRead(ThermistorPin2);
  
  Vout = adc * Vs/adcMax;
  Rt = R1 * Vout / (Vs - Vout);

  Vout2 = adc2 * Vs/adcMax;
  Rt2 = R1 * Vout2 / (Vs - Vout2);
  
 T = 1/(1/To - log(Rt/Ro)/Beta); // Temperature in Kelvin
 Tc = T - 273.15;                   // Celsius

 T2 = 1/(1/To - log(Rt2/Ro)/Beta); // Temperature in Kelvin
 Tc2 = T2 - 273.15;                   // Celsius
  Serial.print("t1:");
  Serial.println(Tc);
  Serial.print("t2:");
  Serial.println(Tc2);

  delay(2000);
}
