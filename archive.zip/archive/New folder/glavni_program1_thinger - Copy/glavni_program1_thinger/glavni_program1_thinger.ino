 /*
 * 
 * 
 * 
 *  ce hoces da dela OTA ---> eset -> network protection -> disable firewall
 */
#define ESP32_RTOS
#include "OTA.h"
#include "credentials.h"
#define THINGER_SERIAL_DEBUG

#include <ThingerESP32.h>
#include "arduino_secrets.h"

/* thinger */
ThingerESP32 thing(USERNAME, DEVICE_ID, DEVICE_CREDENTIAL);
bool thingerWork;
 
/* thermistor{ */
int ThermistorPin, ThermistorPin2;
double adcMax, Vs;
double R1 = 10000.0;   // voltage divider resistor value
double Beta = 3871.22;  // Beta value
double To = 298.15;    // Temperature in Kelvin for 25 degree Celsius
double Ro = 8000;   // Resistance of Thermistor at 25 degree Celsius

double Vout, Rt, Vout2, Rt2 = 0;
double Tk, Tc, Tf, Tk2, Tc2, Tf2 = 0;
double adc, adc2 = 0;
/* thermistor} */

int grelec = 25;
int crpalka = 26;//
int ong = 27; //on gumb, pritisk je dela kavo, dolg pritisk je on off timer
int wtemp = 80;//working temperature

long buttonTimer = 0;
long longPressTime = 5000;

/* Setting PWM Properties */
const int PWMFreq = 500; /* 500Hz */
const int PWMChannel = 0;
const int PWMResolution = 8;
const int MAX_DUTY_CYCLE = (int)(pow(2, PWMResolution) - 1);

boolean buttonActive = false;
boolean longPressActive = false;



void setup() {
  // put your setup code here, to run once:
  Serial.begin(112500);
  setupOTA("kavomat", mySSID, myPASSWORD);

  pinMode(ong, INPUT_PULLUP);
  pinMode(crpalka, OUTPUT);//crpalka
  pinMode(grelec, OUTPUT);//Grelec
  digitalWrite(crpalka, LOW);
  digitalWrite(grelec, LOW);

  ThermistorPin = 34;//tmin
  ThermistorPin2 = 35;//tmax
  adcMax = 4095.0; // ADC resolution 12-bit (0-4095)
  Vs = 3.3;        // supply voltage
  
  thing.add_wifi(SSID, SSID_PASSWORD);
  thing["millis"] >> outputValue(millis());
  thing["temp1"] >> outputValue(Tc);
  thing["temp2"] >> outputValue(Tc2);
  thing["working_temp"] << inputValue(wtemp);
  thing["worksBetter"] << inputValue(thingerWork);


  ledcSetup(PWMChannel, PWMFreq, PWMResolution);
  /* Attach the crpalka PWM Channel to the GPIO Pin */
  ledcAttachPin(crpalka, PWMChannel);


  Serial.print("ready");
}


void loop() {
//DEBUG
//Serial.print(wtemp);
//Serial.print(thingerWork);
//END_DEBUG

  getTemp();
  thing.handle();

  if (thingerWork == true){
    Serial.print("sprozen zunanji work");
    worksBetter();
  }

  #ifdef defined(ESP32_RTOS) && defined(ESP32)
      #else // If you do not use FreeRTOS, you have to regulary call the handle method.
        ArduinoOTA.handle();
  #endif

  if (digitalRead(ong) == 0) {
    // start timer for long or short press of the button
    if (buttonActive == false) {
      buttonActive = true;
      buttonTimer = millis();
    }
    
    // handling long press of the button -> turn on/off timer
    if ((millis() - buttonTimer > longPressTime) && (longPressActive == false)) {
      longPressActive = true;
      Serial.println("long press");
      
      
    }
  }
  else { // button not pressed

    if (buttonActive == true) {

      if (longPressActive == true) {

        longPressActive = false;
      }
      else {
        //short press -> make coffe
        worksBetter();
        Serial.println("short press");
        delay(10);

      }
      buttonActive = false;
    }
  }
}

void worksBetter(){

  Serial.print("Inside worksBetter");
  //analogWriteFrequency(10000); // set frequency to 10 KHz for all pins
 // analogWrite(crpalka,110, 1024); // pwm nastima crpalko na čisto počasi %
  ledcWrite(PWMChannel, 100);/* pwm(. , dutycicle)*/

 
     int startTime = millis();
     while(millis() - startTime < 55000) { //cajt za nardit kavo
     Serial.print("Inside worksBetter while");
     Serial.println("Pretekli cas: ");
     int time = millis() - startTime;
     Serial.print(time);
     // get temp
     getTemp(); 
    
    if (Tc2 <= wtemp-10) {
      // palimo grelec
      digitalWrite(grelec, HIGH);
      Serial.println("Inside worksBetter temp je pod 70 -> uzigam T=");
      Serial.print(Tc2);
    }
    else if (Tc2 >= wtemp) {
      // ugasnemo grelec
      digitalWrite(grelec, LOW);
      Serial.println("Inside worksBetter temp je nad 80 -> ugasam T=");
      Serial.print(Tc2);
    }
    
 }
 

   digitalWrite(grelec, LOW); // ugasnemo grelec
  
   delay(5000); // za shladit grelec
  
   //analogWrite(crpalka, 0); // ugasnemo crpalko
   ledcWrite(PWMChannel, 0);
   thingerWork = false;
   Serial.print("End of worksBetter");
   delay(500);
  
 
 
}

void getTemp() {
  
  
 
  adc = analogRead(ThermistorPin);
  adc2 = analogRead(ThermistorPin2);
  
  Vout = adc * Vs/adcMax;
  Rt = R1 * Vout / (Vs - Vout);

  Vout2 = adc2 * Vs/adcMax;
  Rt2 = R1 * Vout2 / (Vs - Vout2);
  
 Tk = 1/(1/To - log(Rt/Ro)/Beta); // Temperature in Kelvin
 Tc = Tk - 273.15;                   // Celsius

 Tk2 = 1/(1/To - log(Rt2/Ro)/Beta); // Temperature in Kelvin
 Tc2 = Tk2 - 273.15;                   // Celsius
//  Serial.print("t1:");
//  Serial.println(Tc);
//  Serial.print("t2:");
//  Serial.println(Tc2);
}
