#define USERNAME "matejknific"
#define DEVICE_ID "kavomat"
#define DEVICE_CREDENTIAL ""

#define SSID "net4gear"
#define SSID_PASSWORD ""